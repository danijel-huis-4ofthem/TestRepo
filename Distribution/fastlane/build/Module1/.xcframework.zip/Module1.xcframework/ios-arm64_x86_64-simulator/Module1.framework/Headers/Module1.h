//
//  Module1.h
//  Module1
//
//  Created by Danijel Huis on 26.02.2025..
//

#import <Foundation/Foundation.h>

//! Project version number for Module1.
FOUNDATION_EXPORT double Module1VersionNumber;

//! Project version string for Module1.
FOUNDATION_EXPORT const unsigned char Module1VersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <Module1/PublicHeader.h>


